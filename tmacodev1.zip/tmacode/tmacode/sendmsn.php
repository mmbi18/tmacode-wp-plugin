<?php 
/////////////////////////////////////////////////////////////////////////
/*
	include( plugin_dir_path( __FILE__ ) . 'simpleHtmlDom.php');
			$translate3 ='https://www.msn.com/en-sg/lifestyle/lifestyle/lenovo-thinkpad-x1-fold-review-the-most-versatile-portable-computer-ever-and-worth-the-usdollar3200-price-with-its-impressive-design/ar-BB1c9IDS';
				$html3 = file_get_html($translate3);
				$html4 = $html3->find('div[class=richtext]',0);
				echo $html4;
  */
        ?>
        <?php 
if ( !is_user_logged_in() ) {
//echo  esc_url( wp_login_url() ); 
  echo "<script>window.location = '".  esc_url( wp_login_url() )."'</script>";

exit();
}


require_once('wp-load.php');
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-includes/pluggable.php' );

function xbackd_upload_image($image_url, $post_id) {
    global $wp_filesystem;
        $upload_dir = wp_upload_dir();
        $imagex = wp_remote_get($image_url);
        $image_data = wp_remote_retrieve_body($imagex);
        $filename = wp_basename($image_url);
        if (wp_mkdir_p($upload_dir['path']))
            $file = $upload_dir['path'] . '/' . $filename;
        else
            $file = $upload_dir['basedir'] . '/' . $filename;
        file_put_contents($file, $image_data);
        $attachment = array(
			'post_mime_type' => 'image/jpeg',
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
            );
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        $res1 = wp_update_attachment_metadata($attach_id, $attach_data);
        $res3 = wp_get_attachment_url($attach_id, $attach_data);
        $res2 = update_post_meta($post_id, "background", ($res3) , true);
}

function shakhes_upload_image($image_url, $post_id) {
    global $wp_filesystem;
        WP_Filesystem();
        $upload_dir = wp_upload_dir();
        $imagex = wp_remote_get($image_url);
        $image_data = wp_remote_retrieve_body($imagex);
        $filename = wp_basename($image_url);
        if (wp_mkdir_p($upload_dir['path']))
            $file = $upload_dir['path'] . '/' . $filename;
        else
            $file = $upload_dir['basedir'] . '/' . $filename;
        $wp_filesystem->put_contents($file, $image_data, FS_CHMOD_FILE);
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
            );
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        require_once( ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        $res1 = wp_update_attachment_metadata($attach_id, $attach_data);
        $res2 = set_post_thumbnail($post_id, $attach_id);
}

function DaeePedram($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}


/* Send_Post */
	global $post;
	if( isset($_POST['ids']) ) {
			$key = tmdbkey;
			$lang = tmdblang;
			$idmovie = $_POST["ids"];
			if (($idmovie != NULL)) {
				$api_1 = DaeePedram( tmdburl. "movie/" . $idmovie . "?append_to_response=images,trailers&language=" . $lang . "&include_image_language=" . $lang . ",null&api_key=" . $key . "");
				$data = json_decode($api_1, TRUE);
				//////////////////////////////////////////

	include( plugin_dir_path( __FILE__ ) . 'simpleHtmlDom.php');
			$translate3 = $_POST['ids'];
				$html3 = file_get_html($translate3);
				$html4 = $html3->find('div[class=richtext]',0);
			
/////////////////////////////////////////////////////////////////////////

        $origImageSrc=array();

// read all image tags into an array
preg_match_all('/<img[^>]+>/i',$html3, $imgTags); 
$cont=0;
for ($i = 0; $i < count($imgTags[0]); $i++) {
  // get the source string
  preg_match('/src="([^"]+)/i',$imgTags[0][$i], $imgage);

  // remove opening 'src=' tag, can`t get the regex right
if(str_ireplace( 'src="', '',  $imgage[0])!='' && $cont<6){

  $origImageSrc[$i] = str_ireplace( 'src="', '',  $imgage[0]);
 // echo str_ireplace( 'src="', '',  $imgage[0]) .'$tma$';
$cont=$cont+1;
    
}

    
}

//////////////////////////////////////////////////////////////////
			//	$html4	= preg_replace('/\s{2,}/', ' ', $html4);
				//echo $plotfarsix;
				
			//	echo $origImageSrc[1]."<hr>".$html4;
			
			
				// ##########################################

				global $current_user; 
				get_currentuserinfo();
				$user_id = $current_user->ID;
			//	echo $origImageSrc[1]."<hr>".$html4;
			
					$html4	= preg_replace('/\s{2,}/', ' ', $html4);
					//	$html4=htmlentities($html4);
					//	$html4=strip_tags($html4);				

	/*
					$translate3 = 'http://translate.parsijoo.ir/translate?mode=en_fa&text=' . urlencode(strip_tags(substr($html4,0,8048)) ) . ',';
				$html3 = file_get_html($translate3);
				$html3 = $html3->find('div[class=translation]',0);
				$html3 = substr(ltrim($html3), 0, -1);
				$plotfarsix	= preg_replace('/\s{2,}/', ' ', $html3);
				//echo $plotfarsix;
			$html4=$html3;
	*/		
		
		
			
				$my_post = array(
					'post_title' => $_POST['tit'] ,
					'post_content' => $html4 . '<br>'.$_POST["plot"],
					'post_status' => 'pending',
					'post_type' => 'post',
					'post_author'   => $user_id
				);
				$upimg=$origImageSrc[3];
				/*
				if($_POST["imgst"]!=''){
				    
				$upimg=$_POST["imgst"];
				}
				*/
				$upimg=$_POST["imgst"];
				$post_id = wp_insert_post($my_post);
				/////////////////////////////////////////
				
				shakhes_upload_image($upimg, $post_id);

				//////////////////////////////////////
			//	xbackd_upload_image($upimgb, $post_id);
				// file_get_contents(get_home_url() .'/?$allhomes' );
			}
			wp_redirect(get_bloginfo('url')."/wp-admin/post.php?post=$post_id&action=edit&classic-editor&classic-editor__forget");
		}
?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>&#1575;&#1585;&#1587;&#1575;&#1604; &#1662;&#1587;&#1578;</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/send/imdb-post.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/send/jquery.min.js"></script>
<style>
.container { text-align:center; margin-bottom:40px; }
#search { margin-bottom:40px; padding:20px; color:#fff; }
#search span { direction:ltr; font:15px calibri; color:#fc0; }
label { background:#222128; margin:40px 0 10px; padding:5px; display:block; color: #d14040; }
p { color: #fc0; }
p input { width:100%; padding:10px; display:block; direction:ltr; }
input[name=imdb_code] { width:200px; margin:auto; }
input[name^=dlboxs] { margin-bottom:10px; }
textarea[name^=dlboxs_series] { margin-bottom:10px; direction:ltr;}
textarea { width:100%; display:block; }
select { width:200px; border:1px solid #ddd; cursor:pointer; }
	input,textarea,select { background: #565466; color: #fff; }
#apf-response {
    width: 50%;
    padding: 15px;
    color: #222;
}
.backtopanel {
width: 15%;
margin-top: 25px;
background: #222;
padding: 8px;
border-radius: 3px;
}
</style>
</head>
<body>

	<main class="container">
		<div id="search">
			&#1606;&#1575;&#1605; &#1705;&#1575;&#1585;&#1576;&#1585;&#1740;: <span><?php echo $user_login; ?></span>
			&#1662;&#1587;&#1578; &#1575;&#1604;&#1705;&#1578;&#1585;&#1608;&#1606;&#1740;&#1705;&#1740;: <span><?php echo esc_attr(stripslashes($user_email)); ?></span>
		</div>
	
			<div class="clearfix"></div>
			<h2>
			    مشخصات جهت کپی اگهی
			    </h2>
		
		<!--Get_Infos-->
<form action="" method="post">
	<tr id="ids_box">
		<td class="label">
			<label for="ids">
			    لینک اخبار
			    MSN
			    </label>
		</td>
		<td class="field">
		    
			<input class="regular-text" type="text" name="tit" id="tit" placeholder="عنوان" value="">
			<input class="regular-text" type="text" name="ids" id="ids" placeholder="https://www.msn.com/en-in" value="">
			
			<input class="regular-text" type="text" name="imgst" id="imgst" placeholder="آدرس تصویر" value="">
		</td>
	</tr>
	
	
	<tr id="plot_box">
		<td class="label">
			<label for="plot">
			    توضیحات
			</label>
		</td>
		<td class="field">
				<textarea rows="5" name="plot" id="plot"></textarea>
		</td>
	</tr>
	
<script type="text/javascript">
</script>
		<br>
		<button id="send_post" type="submit">&#1575;&#1585;&#1587;&#1575;&#1604; &#1662;&#1587;&#1578;</button>
</form>
<div class="clearfix"></div>
			<div class="backtopanel">
			<a href="<?php bloginfo('url'); ?>/wp-admin/" style="background: transparent;">&#1576;&#1575;&#1586;&#1711;&#1588;&#1578; &#1576;&#1607; &#1662;&#1606;&#1604; &#1575;&#1583;&#1605;&#1740;&#1606; </a>
	</div>
	</main>
</body>
</html>