<?php
/* 
Plugin Name: پلاگین ویرایش کد 
Plugin URI: www.t-ma.ir
Version: 1
Author: t-ma.ir
Description:  [tma_code t1="" t2="" tcode="" ]   [languagetag language='fa' text='گروه نرم افزاری تیما در خدمت شما' lana='fa,en' ]  ?lan$en طراحی شده به دست گروه تیما
*/
define('APFSURL', WP_PLUGIN_URL."/".dirname( plugin_basename( __FILE__ ) ) );
define('APFPATH', WP_PLUGIN_DIR."/".dirname( plugin_basename( __FILE__ ) ) );


if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}


// add_shortcode( 'tma_rnd', 'tmarnd' );
 
 add_shortcode( 'tma_code', 'tmacode' );
 
 add_shortcode( 'tma_whois', 'tmawhois' );
 add_shortcode( 'tma_hostpars', 'tmahostpars' );
 add_shortcode( 'tma_tablegeturl', 'tmahtablegeturl' );
function tmahtablegeturl( $atts ) {
    
 //  	$translate3 = 'http://whoise.ir/info/site/'. $_GET["domains"];
		$wporg_atts = shortcode_atts(
        array(
            'url' => 'https://www.dolathost.com/domain/',
            's' => 'table id="myTable" cellspacing="1" cellpadding="0"  class="table table-striped table-bordered"',
            'e' => 'table',
            'atag' => '1',
            'remtag' => '',
            'tith' => '',
            'titf' => 'جهت اطلاعات بیشتر و خرید تماس بگیرید',
        ), $atts, $tag
    );	
             $origImageSrc=array();
$html = file_get_contents($translate3 = $wporg_atts['url']);
 
preg_match_all('/<'.$wporg_atts['s'].'>(.*?)<\/'.$wporg_atts['e'].'>/s', $html, $matches);

//preg_match_all('/<tr class="row-7 odd">(.*?)<\/tr>/s', $html, $prpay);
/*
$matches[0][0]=str_replace("پارسه","پایه1",$matches[0][0]);
$matches[0][0]=str_replace("پاسارگاد","پیام",$matches[0][0]);
$matches[0][0]=str_replace("پرطرفدار","بیشترین",$matches[0][0]);
$matches[0][0]=str_replace("نامحدود طلایی","بی نهایت",$matches[0][00]);
*/
//echo $html;
if($matches[0][0]==null){
    ?>
    <hr>
    <br> 
 اطلاعاتی جدیدی نیست چون درحال بروز رسانی هستیم
 <?php
}else{
    
			//	$plotfarsix=$matches[0][0];
			//remtag
			if($wporg_atts['remtag']!=''){
			    
    	$matches[0][0]=strip_tags($matches[0][0], $wporg_atts['remtag']);
			}
			if($wporg_atts['atag']=='1'){
    	$plotfarsix=strip_tags($matches[0][0], '<table><thead><th><p><span><div><tr><td><svg><g><path><tr><th><div><center><ul><ui>');
			}else{
			    $plotfarsix=$matches[0][0];
			}
echo $wporg_atts['tith'];
echo $plotfarsix;
echo $wporg_atts['titf'];

echo '<hr>';
?>

<?php
}

}
 
function tmahostpars( $atts ) {
    
 //  	$translate3 = 'http://whoise.ir/info/site/'. $_GET["domains"];
			
             $origImageSrc=array();
$html = file_get_contents($translate3 = 'https://pars.host/linux-host/');
 
preg_match_all('/<table id="tablepress-1" class="tablepress tablepress-id-1 service-table table-striped table-hover table-condensed">(.*?)<\/table>/s', $html, $matches);

preg_match_all('/<tr class="row-7 odd">(.*?)<\/tr>/s', $html, $prpay);
$matches[0][0]=str_replace("پارسه","پایه1",$matches[0][0]);
$matches[0][0]=str_replace("پاسارگاد","پیام",$matches[0][0]);
$matches[0][0]=str_replace("پرطرفدار","بیشترین",$matches[0][0]);
$matches[0][0]=str_replace("نامحدود طلایی","بی نهایت",$matches[0][0]);
$matches[0][0]=str_replace("نامحدود","پیشنهادی بیشتر از 2 گیگابایت",$matches[0][0]);
$matches[0][0]=str_replace(".ir","",$matches[0][0]);
$matches[0][0]=str_replace("KeepAlive","پشتیبانی در راهندازی سایت",$matches[0][0]);
if($matches[0][0]==null){
    ?>
    <hr>
    <br> 
 ارتباط شما با سرور ما قطع شد
    <?php
}else{
    
			//	$plotfarsix=$matches[0][0];
    	$plotfarsix=strip_tags($matches[0][0], '<table><thead><th><p><span><div><tr><td><svg><g><path>');
			
echo $plotfarsix;
echo 'جهت اطلاعات بیشتر و خرید تماس بگیرید';

echo '<hr>';
?>
<!--
<form action="https://t-ma.ir/cp/pay/index.php">
    <input type="number" id="phone" name="phone" placeholder="09شماره موبایل" pattern="[0-9]">
    <input type="text"  name="card_number" id="card_number" class="disbaled_cc required-input valid" maxlength="16" placeholder="شماره کارتxxxx-xxxx-xxxx-xxxx">
    <input type="number" onchange="vmsNationalCode(this.value)" id="idc" placeholder="001*******کد ملی" name="idc">
<script>
function vmsNationalCode($input) {
    if (!preg_match("/^\d{10}$/", $input)
|| $input=='0000000000'
|| $input=='1111111111'
|| $input=='2222222222'
|| $input=='3333333333'
|| $input=='4444444444'
|| $input=='5555555555'
|| $input=='6666666666'
|| $input=='7777777777'
|| $input=='8888888888'
|| $input=='9999999999') {
        return false;
    }
    $check = (int) $input[9];
    $sum = array_sum(array_map(function ($x) use ($input) {
        return ((int) $input[$x]) * (10 - $x);
    }, range(0, 8))) % 11;
    return ($sum < 2 && $check == $sum) || ($sum >= 2 && $check + $sum == 11);
}
</script>
  <label for="cars">
      انتخاب محصول
 هزینه سالانه
  </label>
  <select name="cars" id="cars">
    
    <?php
    $prpay[0][0]= str_replace('<td class="column-1">هزینه سالانه</td>',"",$prpay[0][0]);
    
    $prpay[0][0]= str_replace('select','select',$prpay[0][0]);
    
    $prpay[0][0]= str_replace('td','option',$prpay[0][0]);
    echo $prpay[0][0];
    ?>
    </select>
  <br><br>
  <input type="submit" value="خرید">
</form>
-->
<?php
}

}
function tmawhois( $atts ) {
    
//[tma_whois tit='گروه تیما']
    
    // override default attributes with user attributes
    $wporg_atts = shortcode_atts(
        array(
            'tit' => 't-ma.ir',
        ), $atts, $tag
    );
    
    if($_GET["domains"]){
    ?>
    
        <form action="" method="get">
<input type="text" name="domains" value='<?=$_GET["domains"]; ?>' placeholder="Search for domains or IP addresses..."></input><br/>
<input type="submit" name="submit" value="جستجو"></input>
</form>
    <?
    echo $_GET["domains"].'<hr>';
        
    //    require_once('simpleHtmlDom.php');
			/*	$html3 = file_get_html($translate3);
				$html3 = $html3->find('p[class=domain-checker-available]',0);
				$html3 = substr(ltrim($html3), 0, -1);
				//$plotfarsix	= preg_replace('</\s{2,}/>', '', $html3);
				//,
				
$html3= str_replace(',','',$html3 );
				$plotfarsix=strip_tags($html3);
				echo $plotfarsix;
    */
   	$translate3 = 'http://whoise.ir/info/site/'. $_GET["domains"];
			
             $origImageSrc=array();
$html = file_get_contents($translate3 = 'http://whoise.ir/info/site/'. $_GET["domains"]);
 
preg_match_all('/<pre>(.*?)<\/pre>/s', $html, $matches);
preg_match_all('/<div class="card-box red">(.*?)<\/div>/s', $html, $rank);
preg_match_all('/<div class="card-box blue">(.*?)<\/div>/s', $html, $rankir);


preg_match_all('/<img[^>]+>/i',$html, $imgTags); 

//HTML array in $matches[1]
$cont=0;

    
//strip_tags()
if($matches[0][0]==null){
    ?>
    <hr>
    <br>
 یافت نشد خرید کنید  
یا ارتباط شما با سرور ما قطع شد
    <?php
}else{
				$plotfarsix=$matches[0][0];
				//$img[0][0];
			//	print_r($rank);
			echo($imgTags[0][1]);
		//	echo strip_tags($rank[0][0]);
			?>
			<hr>
			<?php
			echo strip_tags(str_replace("brightness_auto","",$rank[0][0]));
			?>
			<hr>
			<?php
			echo strip_tags(str_replace("font_download","",$rankir[0][0]));
				echo $plotfarsix;
}
    }else{
        
    echo $wporg_atts['tit'];
        ?>
        <form action="" method="get">
<input type="text" name="domains" placeholder="Search for domains or IP addresses..."></input><br/>
<input type="submit" name="submit" value="جستجو"></input>
</form>
        <?php
    }
    
}
 
 
 add_shortcode( 'languagetag', 'wpdocs_bartag_func' );
function wpdocs_bartag_func( $atts ) {
    ///////////////////

	 if(isset($_SERVER['PATH_INFO']))
    $path = (substr($_SERVER['PATH_INFO'], -1) == '/') ? substr($_SERVER['PATH_INFO'], 0, -1) : $_SERVER['PATH_INFO'];
else
    $path = (substr($_SERVER['REQUEST_URI'], -1) == '/') ? substr($_SERVER['REQUEST_URI'], 0, -1) : $_SERVER['REQUEST_URI'];

$url_parts = explode('?lan$', substr($path, 1));
////////////////////////////////////////////////////////////////////

$atts = array_change_key_case( (array) $atts, CASE_LOWER );
 
    // override default attributes with user attributes
    $wporg_atts = shortcode_atts(
        array(
            'language' => 'en',
            'text' => 'hi my name is mohammad bagheri.',
            'lana' => 'fa,en',
        ), $atts, $tag
    );
    
    if($wporg_atts['language']!="" && $wporg_atts['text']!="" && $wporg_atts['lana']!="" && $url_parts[1]!=null){
        
        

////////////////////////////////////////////////

//$url_parts[1]
//[ tma_lan="en" text="hi my name is ali." lana='fa,en' ]
if($url_parts[1]==''){
    $url_parts[1]=$wporg_atts['language'];
}
if($url_parts[1]!='' ){
//************************************************
	require_once('simpleHtmlDom.php');
				$translate3 = 'http://translate.parsijoo.ir/translate?mode='.$wporg_atts['language'] .'_'.$url_parts[1] .'&text=' . urlencode($wporg_atts['text']) . ',';
				$html3 = file_get_html($translate3);
				$html3 = $html3->find('div[class=translation]',0);
				$html3 = substr(ltrim($html3), 0, -1);
				$plotfarsix	= preg_replace('/\s{2,}/', ' ', $html3);
				echo $plotfarsix;
}
//*************************


}else{
    echo $wporg_atts['text'];
}
}

function tmalan( $atts = [], $content = null, $tag = ''  ) {
    echo 'x';
 
    }
    

//cont="-1"

function tmacode( $atts = [], $content = null, $tag = ''  ) {
    
    ////////////////////////////////
    
$atts = array_change_key_case( (array) $atts, CASE_LOWER );
 
    // override default attributes with user attributes
    $wporg_atts = shortcode_atts(
        array(
            't1' => '',
            't2' => '',
            'tcode' => '',
            'url' => '',
        ), $atts, $tag
    );
    
    if($wporg_atts['t1']!="" && $wporg_atts['t2']!="" && $wporg_atts['tcode']!=""){
        
        
     //   echo  $wporg_atts['t1'] .$wporg_atts['t2'] ;
        
       //  echo do_shortcode('[dwqa-list-questions]'); 
       // 
     //$var=  str_replace("[", "", );
   //  echo  $wporg_atts['tcode'];
        $var = do_shortcode( '['.$wporg_atts['tcode']. ']' );
        $t1 = explode(',', $wporg_atts['t1']);
$t2 = explode(',', $wporg_atts['t2']);
$cunt=0;
foreach ($t1 as $value) {
//  echo "$value <br>";

$var= str_replace($t1[$cunt], $t2[$cunt],$var );
    $cunt=$cunt+1;
}
    echo $var;
}else{
 
     if($wporg_atts['t1']!="" && $wporg_atts['t2']!="" && $wporg_atts['tcode']!="tmalink" ){

         $htmltma = file_get_contents($wporg_atts['url']);
       //  $htmltma= str_replace($t1[$cunt], $t2[$cunt],$htmltma );

      $t1 = explode(',', $wporg_atts['t1']);
$t2 = explode(',', $wporg_atts['t2']);
$cunt=0;
foreach ($t1 as $value) {
//  echo "$value <br>";
if($t1[$cunt]!=$t2[$cunt]){
$htmltma= str_replace($t1[$cunt], $t2[$cunt],$htmltma );
}else{
	require_once('simpleHtmlDom.php');
				$translate3 = 'http://translate.parsijoo.ir/translate?mode=en_fa&text=' . urlencode($t1[$cunt]) . ',';
				$html3 = file_get_html($translate3);
				$html3 = $html3->find('div[class=translation]',0);
				$html3 = substr(ltrim($html3), 0, -1);
				$plotfarsix	= preg_replace('/\s{2,}/', ' ', $html3);
				echo $plotfarsix;

$htmltma= str_replace($t1[$cunt], $plotfarsix,$htmltma );
    
}
    $cunt=$cunt+1;
}
echo $htmltma;
     }

        
        

//echo  $wporg_atts['t1'] .$wporg_atts['t2'] ;
  
    }
    //////////////////////////////////
    
}
function function_tma_send(){
    	 if(isset($_SERVER['PATH_INFO']))
    $path = (substr($_SERVER['PATH_INFO'], -1) == '/') ? substr($_SERVER['PATH_INFO'], 0, -1) : $_SERVER['PATH_INFO'];
else
    $path = (substr($_SERVER['REQUEST_URI'], -1) == '/') ? substr($_SERVER['REQUEST_URI'], 0, -1) : $_SERVER['REQUEST_URI'];

$url_parts = explode('?', substr($path, 1));
if($url_parts[1]=='sendtma_sheypoor'){
include( plugin_dir_path( __FILE__ ) . 'sendp.php');
exit();
}


if($url_parts[1]=='sendtma_msn'){
    
include( plugin_dir_path( __FILE__ ) . 'sendmsn.php');
exit();

}

}
add_action('wp', 'function_tma_send');
function Load_tma_code_css(){
    /*
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $location);
    exit;
}
*/


    ?>


    <?php

    
}
//add_action( 'admin_enqueue_scripts', 'safely_add_stylesheet_to_admin_tma_h' );
 function safely_add_stylesheet_to_admin_tma_h() {
     
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $location);
    exit;
}
   //    wp_enqueue_style('boot_css', plugins_url('css/adminBar.css',__FILE__ ));
     //   wp_enqueue_style('boot_css', plugins_url('css/a.css',__FILE__ ));
        ?>
        <link rel="icon" href="<?php echo plugins_url('logo.png',__FILE__ ) ?>">
        <link rel="shortcut icon" href="<?php echo plugins_url('logo.png',__FILE__ ) ?>">
        <style>
        .tmaid{
    position: fixed;
    margin-top: 20%;
    margin-right: 10%;
}
        #bgloader{
   width: 100vw;
    height: 100vh;
    background: white;
    z-index: 9999;
    position: fixed;
    top: 0;
}
/* Center the loader */
#loader {
  position: fixed;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
     border-top: 16px solid #f1b5cc;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>
<div id="bgloader">

<div id="loader"></div>
<h1 class='tmaid'>
طراحی توسعه گروه تیما
سازگار با 
WP
<?=':)' ?>
<br>
php,js,app

</h1>
</div>
<script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 5000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
   document.getElementById("bgloader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}


</script>
        <?php
 }
//admin_footer
//add_action( 'admin_footer', 'safely_add_stylesheet_to_admin_tma' );

  function safely_add_stylesheet_to_admin_tma() {
 wp_enqueue_style('boot_css', plugins_url('css/adminBar.css',__FILE__ ));
        wp_enqueue_style('boot_css', plugins_url('css/a.css',__FILE__ ));
        
        
    //    wp_enqueue_style('boot_css', plugins_url('css/jquery.selectBoxIt.css',__FILE__ ));
      //  wp_enqueue_style('boot_css', plugins_url('css/magnific-popup.css',__FILE__ ));
   //     wp_enqueue_style('boot_css', plugins_url('css/general.css',__FILE__ ));
        
        
       //  wp_enqueue_script('boot_js', plugins_url('js/jquery.oLoader.js',__FILE__ ));
       // wp_enqueue_script('boot_js', plugins_url('js/app.js',__FILE__ ));
?>



<style type="text/css">

body.wp-admin #adminmenuback, body.wp-admin #adminmenuwrap, body.wp-admin #adminmenu {
    background: #FFC107;

  
}
#wpadminbar {
    color: #fff;
    background: #FFC107;
        z-index: 8888;
}
#wpadminbar {
    z-index: 777;
    height: 65px;
}
.ab-sub-wrapper{
    display: none;
}
#wpadminbar #wp-toolbar li#wp-admin-bar-wp-logo > .ab-item span.ab-icon {
    background-image: url(https://t-ma.ir/wp-content/uploads/2020/07/tima.png)!important;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center center;
    margin: 0%!important;
    max-width: 80%;
    height: 70%;
    top: 15%;
}
#wpwrap {
        margin-top: 10%;
}

#wpadminbar{
position: fixed;
}
</style>

<script type="text/javascript">

				jQuery(document).ready(function($) {
					$("div[class*=notice]").hide();

$("h1:contains('پیشخوان')").html('گروه تیما داشبورد');

$("li>a>div[class*=wp-menu-name]:contains('پیشخوان')").html('گروه تیما داشبورد');

///////////////////////////////////////////////
//
//
//
$("span:contains('وضعیت ووکامرس')").html('وضعیت فروشگاه');

$("span:contains('المنتور')").html('ویرایشگر تیما');
$("a:contains('Frontend Editor)").html('ویرایش دیداری');
//footer-thankyou
//
tmafot='طراحی توسعه داده شده با سیستم ترکیبی بومی وردپرسی تیما';
$("[id*='footer-left']").html('<center>www.teima.ir<br>www.t-ma.ir<br>'+tmafot +'</center>'); 

//
//

var footer='سیستم بومی تیما';
/*
$("div[class*='clear']:contains('')").html('<center>www.t-ma.ir<br>'+footer +'</center>'); 
*/

$("div[class*='wp-menu-name']:contains('ووکامرس')").html('فروشگاه'); 


$("div[class*='wp-menu-name']:contains('Element Pack')").html('t-ma Pack'); 
$("div[class*='wp-menu-name']:contains('المنتور فارسی')").html('تیما فارسی'); 

$("div[class*='wp-menu-name']:contains('Progressive Apps')").html('نرم افزار تیما'); 
$("div[class*='wp-menu-name']:contains('Hide My WP')").html('Hide My'); 
$("h1:contains('وردپرس')").html('سیستم بومی تیما'); 

				});
				
				myFunction();
			</script>
<?php
    }


//add_action('plugins_loaded', 'Load_tma_code_css', 100);

function wpb_login_logo() { 
$plurl=plugin_dir_url( __FILE__ );
include( 'p5js/miclogin/index.php');
?>


    
<?php
}
add_action( 'login_enqueue_scripts', 'wpb_login_logo' );
