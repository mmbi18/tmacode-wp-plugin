            //-----------------------------------------
            
//$('body').css('background-image', 'url(' + '../admin/bg1.jpg' + ')');
//content-page

//$("div[id*='content-page']").css('background-image', 'url(' + '../admin/bg1.jpg' + ')');
//background-repeat: no-repeat;
//$("div[id*='content-page']").css('background-size','cover');
//$("div[id*='content-page']").css('opacity','0.6');    background: transparent\9;

//$("div[id*='content-page']").css('background','transparent\9');

$('body').oLoader({
  wholeWindow: true,
  backgroundColor: "url('../bg1.jpg') top center",
  fadeLevel: 2,
  fadeInTime: 10,
  image: '../favicon-144.png',
  hideAfter: 4000
});
            //------------------------------------
            //label
        //    $('*').find('label').css('color','blue');
            //div[class*=form-label]
          //  $('*').find('div[class*=form-label]').css('color','green');
            
            
            $("li>h3>a:contains('آگهی')").after('/گالری');
                            
            //-----------------------------------
            $('*').find('h1').css('color','blue');
            
            $('*').find('a').css('color','blue');
            
              //  $("h3:eq(11)").html('دسته بندی');
            //widget-box-title
            //    $("h3:eq(12)").html('آمار بازدید');
            
            $("h3:contains('تبلیغات بر اساس دسته بندی')").html('دسته بندی');
           // $("h3:contains('')").html('');
            $("[value*=listing]").html('پست های جدید');
            
            
            $("td:contains('آگهی')").html(' لیست دستگاه');
            
           $("b:contains('آگهی‌های جدید')").html('پست های جدید');
           $("h3:contains('آگهی جدید')").html('پست جدید');
           $("h3:contains('بازدید آگهی ها')").html(' بازدید'); 
            //متوسط آگهی هر کاربر
            $("h3:contains('متوسط آگهی هر کاربر')").html('فعالیت های نمایندی ها'); 
            
            $("h3:contains('کاربران هر استان')").html('فعالیت نمایندگان هر استان'); 
            //
           $("div.stats-detail:contains('تعداد کل آگهی‌ها')").html('----------');
            //
            
        
                   
           $("[id*=b_link]").after('نمایان در منو/');
            //$("div:contains('')").html('');
            //$("div:contains('آگهی ها')").html('پست ها');
            html_web=$( "[id*=content-head]" ).html();
html_web=html_web.replace("آگهی", "پست");
html_web=html_web.replace("اضافه کرن آگهی", "افزودن پست");
$( "[id*=content-head]" ).html(html_web);
// ///////////////////////////////


//---------------------save-ch
$( "input[value*='Save changes']" ).val('ذخیره تغییرات');


$( "input[value*='Remove image']" ).val('حذف تصویر');

$( "input[value*='Upload']" ).val('بارگذاری');
$( "input[value*='Remove logo']" ).val('حذف آرم');

//-----------------------------

            $("[id*=items_manage]").html('پست ها');
            $("[id*=items_reported]").html(' پست گذارش شده');
//settings_osclasswizards

            $("[id*=settings_osclasswizards]").html('تنظیمات قالب');
            
                        $("[id*=stats_items]").html('پست ها');

                        $("[class*=render-title]").html('<br><br><hr><br><hr>');
                        $("[class*=stats-title]").html('*');
//.remove();osclasswizards
                        $("[class*=wizards_brand]").remove();
                        $("[id*=documentation]").remove();
                        //
$("[title*=osclasswizards]").remove();
                        
$("[name*=iDisplayLength]").remove();



                        $("[id*=footer-wrapper]>[id*=footer]").after('<br>طراحی شده با هسته باز پی اچ پی ، جاوااسکریپت، جی کوئری ، پروژه های متن باز ، ایده گرفته شده از وردپرس و جملا و....  <br> سیستم بومی  طراحی شده به کمک چند هسته پروژه می باشد');
                        $("[id*=footer-wrapper]>[id*=footer]").after('<a>mr mrdi rsuli</a> & <a>mohammad bagheri </a>&<a>ali abbasi</a> & <a>php</a> & <a>js,qj</a>');

$("[id*=footer-wrapper]>[id*=footer]").after( '<center>***بعضی امکانات ممکن است در قالب شما فعال نباشد***</center>');
//-----------------------------------------
 
            //---------------------------------------
            
//General
    $("a:contains('General')").html('عمومی');
        //Templates
        
    $("a:contains('Templates')").html('قالب ها');
    //Image Uploads
    $("a:contains('Image Uploads')").html('بارگذاری تصویر');
    //Category Icons
    $("a:contains('Category Icons')").html('نمادهای دسته');
    //Ads Management
    $("a:contains('Ads Management')").html('مدیریت تبلیغات');
    
    $("a:contains('Ads Management')").html('');
    
    
    $("a:contains('Facebook Page')").html('صفحه فیس بوک');
    
    
    $("a:contains('Documentation')").html('مستندات');
        
        
        
    $("a:contains('Theme Settings')").html('تنظیمات پوسته');
    
    $("a:contains('Theme Style')").html('سبک تم');
    
    $("div[class*=form-label]:contains('Theme color mode')").html('حالت رنگ تم');
    
    $("div[class*=form-label]:contains('Body fonts')").html('حقلمهای بدن');
    
    
    $("div[class*=form-label]:contains('Heading fonts')").html('قلمهاي عنوان');
	
    $("div[class*=form-label]:contains('RTL view')").html('نمايش RTL');
	
    $("div[class*=form-label]:contains('Custom CSS')").html('CSS سفارشي');
    
    
    
    // ------------------------------------------------------------
    
    $("div[class*=help-box]:contains('Right to left view.')").html('نماي سمت راست به چپ');
	
	
   $("div[class*=help-box]:contains('You can write your custom CSS and override the default CSS.')").html('مي توانيد CSS دلخواه خود را بنويسيد و CSS پيش فرض را ناديده بگيريد.');
	
    $("div[class*=form-label]:contains('Welcome message')").html('پيام خوش امد گويي');
	
   $("div[class*=form-label]:contains('Footer message')").html('پيام پاورقي');
	
    $("a:contains('Home')").html('خانه');
        
        $("a:contains('Home')").html('خانه');
        
        $("a:contains('Search')").html('جستجو');
        
        $("a:contains('Item Post')").html('مورد پست');
        //------------------------------------------------------
        
    $("div[class*=form-label]:contains('Search placeholder')").html('جستجوی مکان یاب');
    
    
    $("div[class*=form-label]:contains('Slider listings (Premium)')").html('لیست کشویی ');
    
    
    $("div[class*=form-label]:contains('Slider listings shown total')").html('لیست کشویی در کل نشان داده شده است');
    
    $("div[class*=form-label]:contains('Show subcategories')").html('نمایش زیر شاخه ها');
    
    
    $("div[class*=form-label]:contains('Subcategories limit')").html('زیر دسته های محدود');
    
    $("div[class*=form-label]:contains('Premium listings shown')").html('لیست های حق بیمه نشان داده شده است');
    
    $("div[class*=form-label]:contains('Category multiple selects')").html('دسته چندگانه را انتخاب می کند');
    
    $("div[class*=form-label]:contains('Title min. length')").html('عنوان حداقل طول');
    
    $("div[class*=form-label]:contains('Description min. length')").html('توضیحات حداقل طول');
    //----------------------------------------------------------------------
    $("div[class*=form-label]:contains('Locations input as')").html('ورودی محل به عنوان');
        $("div[class*=form-label]:contains('Locations required')").html('مکان های مورد نیاز');
        //----------------------------------------------------------------
        $("a:contains('Logo')").html('لوگو');
        $("a:contains('Favicon')").html('فاویکون');
        
        $("a:contains('Banner')").html('بنر');
        
        $("p:contains('The preferred size of the logo is 177x30 pixels.')").html('اندازه دلخواه آرم 177x30 پیکسل است.');
        
        $("p:contains(' Uploading another logo will overwrite the current logo.')").html('بارگذاری یک آرم دیگر ، آرم فعلی را رونویسی می کند.');
        
        $("div[class*=form-label]:contains('Logo image (only jpg)')").html('تصویر آرم (فقط jpg)');
        
        $("p:contains('The preferred size of the favicon is 16x16 pixels.')").html('اندازه ترجیحی favicon 16x16 پیکسل است.');
        
        $("p:contains(' Uploading another image will overwrite the current image.  ')").html('بارگذاری تصویر دیگر، تصویر فعلی را بازنویسی می کند.');
        
        $("p:contains('No image has been uploaded yet')").html('هنوز تصویری بارگذاری نشده است');
        
        $("p:contains('In this section you can configure your site to display ads and start generating revenue.')").html('در این بخش می توانید سایت خود را برای نمایش تبلیغات و شروع به تولید درآمد پیکربندی کنید. <br>اگر از یک پلت فرم تبلیغاتی آنلاین مانند Google Adsense استفاده می کنید ، کد ارائه شده برای تبلیغات را کپی و جایگذاری کنید.');
        
        $("a:contains('Favicon')").html('');
        
        //---------------------------
        $("div[class*=form-label]:contains('Accepted image (png,gif,jpg)')").html('تصویر پذیرفته شده (png ، gif ، jpg)');
        $("div[class*=form-label]:contains('Title')").html('عنوان');
        
        
        $("div[class*=form-label]:contains('Header Ad')").html('هدر تبلیغ');
    //Homepage Ad
    
        $("div[class*=form-label]:contains('Homepage Ad')").html('تبلیغات صفحه اصلی');
        $("div[class*=form-label]:contains('Homepage Sidebar Ad')").html('تبلیغات صفحه نوار جانبی');
    
        $("div[class*=form-label]:contains('Search results Ad (top of the page)')").html('نتایج جستجو (بالای صفحه)');
    
    
    
    
        $("div[class*=form-label]:contains('Search results Ad (bottom of the page)')").html('نتایج جستجو (پایین صفحه)');
        
        $("div[class*=form-label]:contains('Sidebar Ad')").html('آگهی نوار کناری');
        $("div[class*=form-label]:contains('Facebook Page URL')").html('آدرس صفحه فیس بوک');
        $("div[class*=form-label]:contains('Width')").html('عرض');
    
        $("div[class*=form-label]:contains('Height')").html('قد');
        
        $("div[class*=form-label]:contains('Hide Cover Photo')").html('مخفی کردن عکس جلد');
        
        $("div[class*=form-label]:contains('Show Friend')").html('نمایش چهره های دوست');
        $("div[class*=form-label]:contains('Show Page Posts')").html('نمایش پست های صفحه');
        $("div[class*=form-label]:contains('Display On Item Sidebar')").html('نمایش در نوار کناری مورد');
        $("div[class*=form-label]:contains('Display On Search Sidebar')").html('نمایش در نوار کناری جستجو');
    
    
    $("div[class*=form-label]:contains('Height')").html('');
    $("div[class*=form-label]:contains('Height')").html('');
    $("div[class*=form-label]:contains('Height')").html('');
    $("div[class*=form-label]:contains('Height')").html('');
    
    
    
     $("a[id*=stats_items]").after('<a target="_blank" href="https://www.revolvermaps.com/livestats/5m79gq6friz/" >آمار آنلاین</a>');   
 
      $("a[id*=stats_items]").after('<a target="_blank" href="https://www.goftino.com/" >پشتیبانی آنلاین</a>');   
 
      $("ul>li>a[id*=stats_reports]").after('<a target="_blank" href="https://www.searchenginegenie.com/google-rank-checker.html" > رتبه سایت در صفحه گوگل</a>');
 //

     $("ul>li>a[id*=stats_reports]").after('<a target="_blank" href="https://www.w3counter.com/stats/130394/dashboard" > آنالیز بازدید</a>');
     
     //------------------------------------plugins_manage
     
     
     
     
     $("ul>li>a[id*=plugins_manage]").after('<a  href="index.php?page=file" > مدیریت فایل </a>');
     
     $("ul>li>a[id*=plugins_manage]").after('<a  href="index.php?page=pdf_o" >  نمایشگر پی دی اف </a>');
     
     $("ul>li>a[id*=plugins_manage]").after('<a  href="index.php?page=editor_o" >سیستم مدیریت تیما </a>');
     
     $("ul>li>a[id*=plugins_manage]").after('<a  href="index.php?page=programmers" >   برنامه نویسان   </a>');
     
     $("ul>li>a[id*=settings_general]").after('<a  href="index.php?page=help" >    راهنما   </a>');
     
     //--------------------------------
  
                            $("a:contains('OsclassWizards')").attr('href','http://t-ma.ir');
                            
                            $("a:contains('OsclassWizards')").html('گروه تیما');
                            
                            $("a[target*=_blank]:contains('Class')").attr('href','http://t-ma.ir');
                            
                            $("a:contains('Class')").html('گروه تیما');
                            
                            
                            
                            
                            $("a:contains('صفحه افزونه ها')").attr('href','http://t-ma.ir');
                            
                            $("a:contains('OsclassWizards')").attr('href','http://t-ma.ir');
                            //DopeThemes
                            $("a:contains('DopeThemes')").attr('href','http://t-ma.ir');
                            //
                            $("td:contains('Rewrite all the urls adding the parameter theme. In addition, it loads the theme passed in the url as parameter. Ideal for showing different themes.')").html('بازنویسی تمام آدرس های اضافه شده با موضوع پارامتر. علاوه بر این ، موضوع ارسال شده در url را به عنوان پارامتر بارگذاری می کند. ایده آل برای نمایش موضوعات مختلف.');
                            $("td:contains('plugin allows you to add an extra styling code or scripts on your site header and footer.')").html('افزونه به شما امکان می دهد یک کد یا اسکریپت یک ظاهر طراحی شده اضافی را در صفحه و صفحه اصلی خود اضافه کنید.');
                            //
                            $("td:contains('SEO Wiz is a free SEO Osclass Plugin for SEO optimization developed by OsclassWizards.')").html('SEO یک افزونه سئو رایگان برای بهینه سازی سئو است که توسط آن ایجاد شده است.');
    $("td:contains('Voting system')").html('سیستم رای گیری');
    //Insert on Header & Footer
    $("td:contains('Insert on Header & Footer')").html('در Header & Footer درج کنید');
                                                    
  
    $("td:contains('SEO')").html('SEO');
                                        
                                        
    $("td:contains('Voting')").html('رأی دادن');  
    $("td:contains('Jalali Date')").html('جلالی تاریخ');
    $("td:contains('OS-Jalali')").html(' تاریخ-جلالی');
    $("td:contains('تاریخ شمسی او اس کلاس فارسی')").html( 'هسته باز تاریخ-جلالی');    
  
    $("td:contains('شمسی سازی تمامی تاریخ های مدیریت و سایت')").html(' شمسی سازی تمامی تاریخ های مدیریت و سایت');
  //OsclassWizards          
  //OsclassWizards
    //Premium osclass themes
    //wizards_address
    
    
                        $("address").remove();
                        /////////////////////////
                        
                        
                        function help_btn1() {
 //                    $(this).css( { 'color': '#770' } );exampleVideo
 var url_help='https://aspb2.cdn.asset.aparat.com/aparat-video/cde60cbdb16c595cb1da8227181cb22c10289934-480p__57513.mp4';
 alert(url_help);
 //("div[class*=row]')").html("html");
                           //$("div[class*=exampleVideo]')").html('						<div class="myVideo" id="my_video" data-video="'+ url_help +'" data-poster="themes/modern/images/favicon-144.png" data-type="video/mp4"><div class="rtopVideoPlayerWrapper"><div class="rtopVideoPlayer rtopTheme hasFA"><div class="rtopVideoHolder hasFAIcons"><video src="https://www.w3schools.com/html/mov_bbb.mp4" playsinline="" type="video/mp4" poster="themes/modern/images/favicon-144.png" id="ccdUQWyevv"><source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4"></video></div><div class="vidControls hasFAIcons hasProgressBar hasTimer hasSound hasFS hasPP"><div id="playPause" class="controlBtn"><span class="FAIcon"><i class="far fa-pause-circle"></i></span></div><div id="progressholder" class="controlBtn"><div id="fullvideoprogress"></div><div id="buffered"></div><div id="progress"></div><div id="progressorb"></div></div><div id="timeholder" class="controlBtn"><span id="currenttime">00:00</span> / <span id="totaltime">00:00</span></div><div id="soundControl" class="controlBtn"><span class="muteBtn FAIcon"><i class="fas fa-volume-up"></i></span><span class="soundBars"><span class="soundBar active" data-value=".25"></span><span class="soundBar active" data-value=".50"></span><span class="soundBar active" data-value=".75"></span><span class="soundBar active" data-value="1"></span></span></div><div id="fullScreenBtn" class="controlBtn"><span class="FAIcon"><i class="fas fa-expand"></i></span></div></div></div></div></div>');
 
                         }
    
